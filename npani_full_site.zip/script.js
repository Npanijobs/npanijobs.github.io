
console.log("NPani Job Portal loaded successfully.");
